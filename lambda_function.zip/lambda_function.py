

import json
import boto3
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
import io
import os
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS services
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
cloudwatch = boto3.client('cloudwatch')
table = dynamodb.Table('ImageMetadata')

def put_metric(name, value, unit):
    """
    Put a metric to CloudWatch
    """
    try:
        cloudwatch.put_metric_data(
            Namespace='ImageProcessing',
            MetricData=[{
                'MetricName': name,
                'Value': value,
                'Unit': unit
            }]
        )
    except Exception as e:
        logger.error(f"Failed to put CloudWatch metric {name}: {str(e)}")

def add_watermark(image):
    """
    Add watermark to image
    """
    try:
        if image.mode in ('RGBA', 'LA'):
            image = image.convert('RGB')
        draw = ImageDraw.Draw(image)
        width, height = image.size
        text = "© MyService 2025"
        x = width - (width / 4)
        y = height - (height / 5)
        draw.text((x, y), text, fill='white', stroke_width=5, stroke_fill='black')
        return image
    except Exception as e:
        logger.error(f"Watermark error: {str(e)}")
        raise

def compress_image(image, file_extension):
    """
    Compress image based on file type
    """
    try:
        buffer = io.BytesIO()
        if file_extension.lower() in ['.jpg', '.jpeg']:
            image.save(buffer, format='JPEG', quality=60, optimize=True)
        elif file_extension.lower() == '.png':
            image.save(buffer, format='PNG', optimize=True)
        elif file_extension.lower() == '.gif':
            image.save(buffer, format='GIF', optimize=True)
        buffer.seek(0)
        return buffer
    except Exception as e:
        logger.error(f"Compression error: {str(e)}")
        raise

def lambda_handler(event, context):
    start_time = datetime.now()
    logger.info("Lambda function started")
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        if 'Records' in event:
            record = event['Records'][0]['s3']
            bucket = record['bucket']['name']
            key = record['object']['key']
        else:
            bucket = 's3-lambda-1735992190'
            key = event.get("key")
            if not key:
                raise ValueError("No image key provided")

        logger.info(f"Processing image: {key}")

        file_extension = os.path.splitext(key)[1].lower()
        if file_extension not in ['.jpg', '.jpeg', '.png', '.gif']:
            raise ValueError(f"Unsupported file type: {file_extension}")

        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            image_data = response['Body'].read()
            original_size = len(image_data)
            put_metric('OriginalSize', original_size, 'Bytes')
        except Exception as e:
            logger.error(f"Failed to read image from S3: {str(e)}")
            raise

        try:
            image = Image.open(io.BytesIO(image_data))
            watermarked = add_watermark(image)
            compressed = compress_image(watermarked, file_extension)
            processed_size = len(compressed.getvalue())
            put_metric('ProcessedSize', processed_size, 'Bytes')
        except Exception as e:
            logger.error(f"Image processing failed: {str(e)}")
            raise

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        processed_key = f"processed/{timestamp}{file_extension}"

        try:
            s3.put_object(
                Bucket=bucket,
                Key=processed_key,
                Body=compressed.getvalue(),
                ContentType=f"image/{file_extension[1:]}"
            )
        except Exception as e:
            logger.error(f"Failed to upload processed image: {str(e)}")
            raise

        compression_ratio = ((original_size - processed_size) / original_size) * 100
        put_metric('CompressionRatio', compression_ratio, 'Percent')

        try:
            table.put_item(
                Item={
                    "ImageID": processed_key,
                    "OriginalKey": key,
                    "Status": "Processed",
                    "Timestamp": datetime.now().isoformat(),
                    "RequestID": context.aws_request_id,
                    "OriginalSize": original_size,
                    "ProcessedSize": processed_size,
                    "CompressionRatio": f"{compression_ratio:.2f}%"
                }
            )
        except Exception as e:
            logger.error(f"Failed to save metadata: {str(e)}")
            raise

        duration = (datetime.now() - start_time).total_seconds() * 1000
        put_metric('ProcessingDuration', duration, 'Milliseconds')

        logger.info(f"Processing completed. Compression ratio: {compression_ratio:.2f}%")
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                "message": "Image processed successfully",
                "original_key": key,
                "processed_key": processed_key,
                "compression_ratio": f"{compression_ratio:.2f}%",
                "processing_time_ms": f"{duration:.2f}"
            })
        }

    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return {
            "statusCode": 400,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            },
            "body": json.dumps({"error": f"Validation error: {str(e)}"})
        }

    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        logger.error("Stack trace:", exc_info=True)
        return {
            "statusCode": 500,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                "error": "An unexpected error occurred.",
                "details": str(e)
            })
        }

